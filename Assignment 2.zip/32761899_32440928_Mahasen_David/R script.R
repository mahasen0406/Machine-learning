library(tidymodels)
library(tidyverse)
library(factoextra)
library(gt)
library(janitor)
library(haven)

#Question 1
#i)
customer <- read_csv("Data/customer.csv")

customer <- customer %>% 
  select(-1) 

customer$has_churned <- factor(customer$has_churned, ordered = T,
                               levels = c("1", "0"))

#Training and testing split
set.seed(61899)

customer_split <- customer %>% 
  initial_split(prop = 0.75, strata = has_churned)

customer_training <- customer_split %>% 
  training()

customer_testing <- customer_split %>% 
  testing()

#Model
logistic_model <- logistic_reg() %>% 
  set_engine("glm") %>% 
  set_mode("classification")

#Recipe
logistic_recipe <- recipe(has_churned ~ ., data = customer_training) %>%
  step_corr(all_numeric_predictors(), threshold = 0.8)

custom_metrics <- metric_set(accuracy, sens, npv, roc_auc)

#Cross validation
set.seed(61899)
customer_folds <- vfold_cv(customer_training, v=5, strata = has_churned)

customer_wkfl <- workflow() %>% 
  add_model(logistic_model) %>% 
  add_recipe(logistic_recipe)

customer_wkfl_fit <- customer_wkfl %>% 
  last_fit(split = customer_split) 

reg_rs_fit <- customer_wkfl %>% 
  fit_resamples(resamples = customer_folds,
                metrics = custom_metrics)

reg_rs_fit %>% 
  collect_metrics()

#ii)
logistic_fit <- logistic_model %>% 
  fit(has_churned ~ ., data = customer_training)

class_predict <- logistic_fit %>%
  predict(new_data = customer_testing,
          type = "class")

probs_predict <- logistic_fit %>%
  predict(new_data = customer_testing,
          type = "prob")

customer_results <- customer_testing %>% 
  select(has_churned) %>% 
  bind_cols(class_predict, probs_predict)

customer_results %>% 
  custom_metrics(truth = has_churned,
                 estimate = .pred_class, .pred_1)

#iii)
customer_prep <- logistic_recipe %>% 
  prep(training=customer_training)

customer_bake <- customer_prep %>% 
  bake(new_data = NULL)

customer_model <- logistic_model %>% 
  fit(has_churned ~ ., data = customer)

tidy(customer_model)

#Question 2
membership <- read.csv("Data/membership.csv")
glimpse(membership)

#look for na values
sum(is.na(membership))

#Factor the characters
membership1 <- membership %>% 
  mutate(across(c(2,5,6), as_factor)) %>% 
  glimpse()

#Split into training and testing data
set.seed(61899)
membership_split <- membership1 %>% 
  initial_split(prop=0.75, strata=subscribe)

membership_train <- membership_split %>% 
  training()

membership_test <- membership_split %>% 
  testing()

membership_cluster <- membership_train %>% 
  select(age, income, kids) %>% 
  scale()


#K means
set.seed(61899)
fviz_nbclust(membership_cluster, FUN= cluster::pam, method= "wss",
             k.max=10)

fviz_nbclust(membership_cluster, FUN= cluster::pam, method= "silhouette",
             k.max=10)

set.seed(61899)
membership_kmeans <- kmeans(membership_cluster,centers=3, nstart = 20)
tidy(membership_kmeans)

membership_cluster1 <- augment(membership_kmeans, data = membership_train) %>% 
  glimpse()

#v)
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

#Descriptive analysis
cluster_descrip <- membership_cluster1 %>% 
  group_by(.cluster) %>% 
  summarise(mode_subscribe = getmode(subscribe),
            mean_age = mean(age, na.rm = T),
            mode_gender = getmode(gender),
            mean_income = mean(income, na.rm = T),
            mean_kids = mean(kids, na.rm = T),
            mode_ownhome = getmode(ownHome)) %>% 
  glimpse()

#Descriptive analysis table
cluster_descrip %>% 
  gt(rowname_col=",cluster") %>% 
  tab_header(title= "Descriptive analysis",
             subtitle= "by Clusters") %>% 
  opt_align_table_header("center") %>% 
  cols_label(mode_subscribe ="Most occuring subscription",
             mean_age = "Average age",
             mode_gender = "Most occuring gender",
             mean_income = "Average income",
             mean_kids = "Average number of kids",
             mode_ownhome = "Most occured homeownership",
             .cluster = "Cluster number")

#Average of age bar chart
cluster_descrip %>% 
  ggplot(aes(x= .cluster, y= mean_age))+
  geom_bar(stat= "identity", fill="#668B8B")+
  labs(title = "Average of age by cluster",
       x = "Cluster",
       y = "Average age")+
  theme(plot.title = element_text(face = "bold", family = "Times", hjust = 0.5),
        panel.background = element_blank(),
        axis.line = element_line(color = "black", size = 0.1),
        text = element_text(family = "Times"))

#Average income by cluster
cluster_descrip %>% 
  ggplot(aes(x= .cluster, y= mean_income))+
  geom_bar(stat= "identity", fill="#668B8B")+
  labs(title = "Average of Income by cluster",
       x = "Cluster",
       y = "Average Income")+
  theme(plot.title = element_text(face = "bold", family = "Times", hjust = 0.5),
        panel.background = element_blank(),
        axis.line = element_line(color = "black", size = 0.1),
        text = element_text(family = "Times"))

#Average number of kids by cluster
cluster_descrip %>% 
  ggplot(aes(x= .cluster, y= mean_kids))+
  geom_bar(stat= "identity", fill="#668B8B")+
  labs(title = "Average number of kids by cluster",
       x = "Cluster",
       y = "Average number of kids")+
  theme(plot.title = element_text(face = "bold", family = "Times", hjust = 0.5),
        panel.background = element_blank(),
        axis.line = element_line(color = "black", size = 0.1),
        text = element_text(family = "Times"))

#frequency and percentage of each gender
membership_cluster1 %>% 
  tabyl(.cluster, gender) %>% 
  adorn_totals("col") %>% 
  adorn_percentages("row") %>% 
  adorn_pct_formatting(digits = 1) %>% 
  adorn_ns(position = "front") %>% 
  gt(rowname_col=",cluster") %>% 
  tab_header(title= "Cross tabulation of genders",
             subtitle= "by Clusters") %>% 
  opt_align_table_header("center") %>% 
  cols_label(.cluster="Cluster number") %>% 
  cols_align("center")

#frequency and percentage of subscriber
membership_cluster1 %>% 
  tabyl(.cluster, subscribe) %>% 
  adorn_totals("col") %>% 
  adorn_percentages("row") %>% 
  adorn_pct_formatting(digits = 1) %>% 
  adorn_ns(position = "front") %>% 
  gt(rowname_col=",cluster") %>% 
  tab_header(title= "Cross tabulation of subscribers",
             subtitle= "by Clusters") %>% 
  opt_align_table_header("center") %>% 
  cols_label(.cluster="Cluster number",
             subNo = "Non-Subscriber",
             subYes = "Subscriber") %>% 
  cols_align("center")

#Question 3
deli_depot <- read_sav("Data/deli depot.sav")

glimpse(deli_depot)

sum(is.na(deli_depot))

cor(deli_depot[c(-1)])

#i)
deli_depot1 <- deli_depot %>% 
  mutate(across(c(x7, x10, x11, moderate:distance_3), as_factor)) %>% 
  select(-c(id, moderate:distance_3)) %>% 
  glimpse()

set.seed(61899)

deli_split <- deli_depot1 %>% 
  initial_split(prop = 0.75, strata = x9)

deli_training <- deli_split %>% 
  training()

deli_test <- deli_split %>% 
  testing()

deli_recipe <- recipe(x9~.,data = deli_training) %>%
  step_normalize(all_numeric()) %>% 
  step_pca(c(x1:x6), threshold = 0.7, id = "pca") %>%
  step_corr(all_numeric_predictors(), threshold = 0.8) %>% 
  step_dummy(all_nominal_predictors())

deli_prep <-deli_recipe %>% 
  prep()

deli_pca_bake_train <- deli_prep %>% 
  bake(new_data = NULL) %>% 
  glimpse()

tidy(deli_prep, id = "pca", type = "coef") %>% 
filter(component%in%c("PC1", "PC2", "PC3")) %>% 
  ggplot(aes(terms, value, fill = component))+
  geom_col(show.legend = F)+
  coord_flip()+
  facet_wrap(~component)+
  scale_y_continuous(labels = scales::percent)+
  theme(plot.title = element_text(hjust = 0.5),
        text = element_text(family = "Times"))
  

tidy(deli_prep, id = "pca", type="coef") %>%
  filter(component%in%c("PC1", "PC2", "PC3")) %>%
  group_by(component) %>% slice_max(abs(value), n=3) %>% 
  ungroup() %>%
  ggplot(aes(terms, abs(value), fill=value>0)) + 
  geom_col()+
  coord_flip()+
  facet_wrap(~ component, scales="free_y") +
  scale_y_continuous(labels = scales::percent) %>%
  labs(title="Components extracted with loadings 
       for 3 highest variables", 
       fill="loading sign",
       y = "loadings (absolute values)", 
       x="items")+
  scale_fill_discrete(labels= c("negative", "positive"))+
  theme(plot.title = element_text(hjust = 0.5),
        text = element_text(family = "Times"))

tidy(deli_prep, id = "pca", type = "variance") %>% 
  view()

lm_model <- linear_reg() %>% 
  set_engine("lm") %>% 
  set_mode("regression")

deli_fit <- lm_model %>% 
  fit(x9 ~ PC1 + PC2 + x7_MALE + x10_Heavy.User + 
        x11_Came.from.1.3.miles + 
        x11_Came.from.more.than.3.miles, data = deli_pca_bake_train)

tidy(deli_fit)
